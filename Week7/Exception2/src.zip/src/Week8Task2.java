import java.io.FileNotFoundException;
import java.io.IOException;

public class Week8Task2 {
    /**
     * Exception.
     * 
     * @return Exception.
     */
    public String nullPointerExTest() {
        try {
            throw new NullPointerException();
        } catch (NullPointerException e) {
            return "Lỗi Null Pointer";
        }
    }

    /**
     * Exception.
     * 
     * @return Exception.
     */
    public String arrayIndexOutOfBoundsExTest() {
        try {
            throw new ArrayIndexOutOfBoundsException();
        } catch (ArrayIndexOutOfBoundsException e) {
            return "Lỗi Array Index Out of Bounds";
        }
    }

    /**
     * Exception.
     * 
     * @return Exception.
     */
    public String arithmeticExTest() {
        try {
            throw new ArithmeticException();
        } catch (ArithmeticException e) {
            return "Lỗi Arithmetic";
        }
    }

    /**
     * Exception.
     * 
     * @return Exception.
     */
    public String fileNotFoundExTest() {
        try {
            throw new FileNotFoundException();
        } catch (FileNotFoundException e) {
            return "Lỗi File Not Found";
        }
    }

    /**
     * Exception.
     * 
     * @return Exception.
     */
    public String ioExTest() {
        try {
            throw new IOException();
        } catch (IOException e) {
            return "Lỗi IO";
        }
    }
}